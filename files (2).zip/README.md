# Divizero サイト修正ガイド

## ファイル一覧と置き換え先

| このファイル | Cursorでの置き換え先 |
|---|---|
| CloserHome.tsx | src/components/closer/pages/CloserHome.tsx |
| CloserAbout.tsx | src/components/closer/pages/CloserAbout.tsx |
| CloserServices.tsx | src/components/closer/pages/CloserServices.tsx |
| CloserPricing.tsx | src/components/closer/pages/CloserPricing.tsx |
| CloserWorks.tsx | src/components/closer/pages/CloserWorks.tsx |
| CloserPartner.tsx | src/components/closer/pages/CloserPartner.tsx |
| closer-divizero-additions.css | 既存の closer-divizero-lp.css の末尾に追記 |

---

## 主な変更内容

### CloserHome.tsx（トップページ）
- ファーストビューにサブコピー追加（「初期費用ゼロ。あなたの代わりに商談を取り続ける...」）
- Painセクションのコピーを共感型に全面改訂
- 「Storyセクション」新規追加（創業ストーリー）
- 「対応ジャンルセクション」新規追加
- 「Howセクション（フロー図）」新規追加（LINE登録〜商談到着の6ステップ）
- Pricingセクションのコピーを「売上が出るまで費用ゼロ」に変更
- 「FAQセクション」新規追加（6問）
- CTAボタン文言を短縮（「まずは無料相談（公式LINE）」）
- Pricing比較カードに「推奨」ラベル追加

### CloserAbout.tsx（Aboutページ）
- 創業ストーリーを具体的に追記
- ブランドネーム「Divizero」の意味を新規追加
- CTAボタン文言を短縮

### CloserServices.tsx（Servicesページ）
- サービス名を「機能名」から「ベネフィット名」に変更
  - 例：「アカウント最適化&ターゲット選定」→「あなたに興味を持ちそうな人だけに、届ける」
- サービス説明文を充実化
- 対応ジャンルセクション追加
- フロー説明追加

### CloserPricing.tsx（Pricingページ）
- ページタイトルを「売上が出るまで、一切費用はかかりません」に変更
- プラン選び方ガイド追加（どちらを選べばいいか明示）
- FAQ追加（3問）
- CTAボタン文言を短縮

### CloserWorks.tsx（Resultsページ）★重要★
- 架空実績カード（「月5アポ」「完全成果報酬」等）を完全削除
- 架空のお客様の声を削除
- 「イメージ」注記も削除
- 代わりに「返信率40%」など実際の数字を大きく表示
- 「この数字が出る理由」セクションで透明性で信頼を構築

### CloserPartner.tsx（Partnerページ）
- エーススタッフのインセンティブ説明を削除（内部情報のため）
- 全体的に簡潔に整理

---

## CSSについて

`closer-divizero-additions.css` を以下のどちらかの方法で反映してください：

**方法A（推奨）**：`closer-divizero-lp.css` の末尾にそのままコピペ

**方法B**：新しいCSSファイルとして保存し、globals.cssかlayout.tsxでimport

---

## 今後の実績が増えたら

`CloserWorks.tsx` の以下のコメントアウト部分を解除して実績カードを追加してください：

```tsx
{/* 
<div className="closer-works-grid">
  実績カードをここに追加
</div>
*/}
```

お客様の声が集まったら `VOICES` 配列を復活させてください。
